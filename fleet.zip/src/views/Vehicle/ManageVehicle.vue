<template>
    <div>
        <ManageVehicle />
    </div>
</template>

<script>
import ManageVehicle from "../../components/Vehicle/ManageVehicle.vue";

export default {
  name: "Manage Vehicle",

  components: {
    ManageVehicle,
  },
};
</script>
