<template>
  <AddVehicle/>
</template>

<script>
import AddVehicle from "../../components/Vehicle/AddVehicle.vue";

export default {
  name: "Vehicle",

  components: {
    AddVehicle,
  },
};
</script>
