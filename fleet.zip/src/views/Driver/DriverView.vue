<template>
  <div>
    <AddDriver />
  </div>
</template>
<script>
import AddDriver from "../../components/Driver/AddDriver.vue"
export default {
  name: "Driver View",
  components:{
    AddDriver
  }
}
</script>